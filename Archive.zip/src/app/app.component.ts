import { Component } from '@angular/core';
import * as IPFS from 'ipfs-mini';
const ipfs = new IPFS({ host: 'ipfs.infura.io', port: 5001, protocol: 'https' });

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'ui-ipfs';
fileName : any;
hash : any;

  onFileSelected(event){
    console.log(event);
    console.log(event.target.files);
    var file = event.target.files[0]
    this.fileName = file.name;
    let fileReader = new FileReader();

    fileReader.onload = (file) => {
      console.log(fileReader.result);
      ipfs.add(fileReader.result)
      .then(hash =>{
        console.log("Uploaded successfully with hash", hash)
        this.hash = hash;
      })
      .catch(console.log);
    }

    fileReader.readAsText(file);
   
  }

}
